COLONY2D CAVE KIT
3 source atlases / 192 cells: cave-surfaces, cave-walls, cave-props.
X/Y orthogonal grid; transparent external backgrounds. Floors remain opaque inside their tiles.
Walls: basalt, limestone, mossy basalt, broken basalt. Each family has 16 connection masks,
ordered N=1 E=2 S=4 W=8 (two rows of eight). Includes isolated pieces, ends, straights,
corners, T junctions and crossings. Rock caps with upright south faces.
Surfaces: dry/wet rock, limestone, gravel, packed earth, moss, mud, water, chasm and transitions.
Props: four-facing entrances and blocked variants, timber supports, stairs, ladder, ramp,
stalagmites/stalactites, coal/iron/crystal/gold deposits and depleted states, fungi, bones,
webs, rails/cart, ripple/drip effects, torch, lantern and campfire states.
The scene preview is an illustration. The game asset library also assembles a cave from actual exports.
Cave art is installed under sprites/autumn/frames but no cave biome/mining gameplay was added.
Open index.html to inspect and download cells. Generated source cells may need bespoke seam polish.
